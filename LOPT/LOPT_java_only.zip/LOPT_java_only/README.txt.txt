The Lopt.jar file is all you need to run it (besides Java). Under Windows, I run it with a batch file containing the following command: 

java -jar C:/WORK/J/LOPT/Lopt.jar %1 %2

I think, under Linux it can be run from a command console as

java -jar Lopt.jar [par-file-name]

(assuming that the system knows the path to Lopt.jar).

Sasha